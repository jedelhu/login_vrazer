<?php $__env->startSection('content'); ?>
    <div class="page-center">
        <div class="page-center-in">
            <div class="container-fluid">

                <form class="sign-box reset-password-box" role="form" method="POST"  action="<?php echo e(url('/password/email')); ?>">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>

                    
                    <header class="sign-title">Reset Password</header>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <input type="text" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>"
                               placeholder="Enter Email">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-rounded">Reset</button>
                    or <a href="<?php echo e(url('/login')); ?>">Sign in</a>
                </form>
            </div>
        </div>
    </div><!--.page-center-->
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>