
<?php $__env->startSection('content'); ?>
<h1>test page</h1>

<?php echo e(Widget::fileSystems()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>