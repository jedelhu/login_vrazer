@extends('admin/layouts/admin')
@section('content')
<h1>test page</h1>

{{ Widget::fileSystems() }}

@stop