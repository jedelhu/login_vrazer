@extends('admin/layouts/admin')
@section('content')
    <h1>test2 page</h1>

    {{ Widget::fileSystems() }}

@stop