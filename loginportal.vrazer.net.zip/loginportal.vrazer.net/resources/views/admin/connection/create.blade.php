
@extends('layout')

@section('content')
<div class="content">
   Data is saved correctly.
</div>
@stop